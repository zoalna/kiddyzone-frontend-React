import React, { Component } from "react";

import "../App.css";
import PartnerDiscount from "../Components/Home/PartnerDiscount";

export default function Elarning() {
  return (
      <>
    <h1>E-LARNING PAGE</h1>
  </>
  );
}
