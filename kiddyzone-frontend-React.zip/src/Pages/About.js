import React, { Component } from "react";

import "../App.css";
import PartnerDiscount from "../Components/Home/PartnerDiscount";

export default function About() {
  return (
      <>
    <h1>About us</h1>
  </>
  );
}
